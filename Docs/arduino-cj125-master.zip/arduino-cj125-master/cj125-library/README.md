# Required Arduino libraries:
- SPI
- PID_v1

# Bosch LSU4.9 5-wire identification:
- IP      red             (czerwony)
- VM      yellow          (żółty)
- HG      white           (biały)
- B+      grey            (szary)
- IA      not connected   (nie podłączony)
- UN      black           (czarny)
