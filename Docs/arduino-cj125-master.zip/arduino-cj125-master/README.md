# Required Arduino libraries:
- SPI
- PID_v1

#Installation:
Create a CJ125 directory under Your Arduino libraries directory.

Drop the content in there & have fun!

# Bosch LSU4.9 5-wire identification:
- IP      red             (czerwony)
- VM      yellow          (żółty)
- HG      white           (biały)
- B+      grey            (szary)
- IA      not connected   (nie podłączony)
- UN      black           (czarny)